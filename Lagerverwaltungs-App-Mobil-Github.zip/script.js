
let products = JSON.parse(localStorage.getItem('products')) || [];
let history = JSON.parse(localStorage.getItem('history')) || [];

function renderProducts() {
    const list = document.getElementById('productList');
    if (!list) return;
    list.innerHTML = '';
    products.forEach((p, i) => {
        list.innerHTML += `<div class='product'><strong>${p.name}</strong><br>Bestand: ${p.quantity} Stück<br><button onclick='takeProduct(${i})'>Entnehmen</button></div>`;
    });
}
function addProduct() {
    const name = document.getElementById('productName').value;
    const image = document.getElementById('productImage').value;
    const quantity = parseInt(document.getElementById('productQuantity').value);
    const category = document.getElementById('productCategory').value;
    const size = document.getElementById('productSize').value;
    products.push({name, image, quantity, category, size});
    localStorage.setItem('products', JSON.stringify(products));
    window.location.href = 'index.html';
}
function takeProduct(index) {
    const amount = prompt('Wie viele möchtest du entnehmen?');
    if (!amount || isNaN(amount) || amount <= 0) return;
    products[index].quantity -= parseInt(amount);
    if (products[index].quantity < 3) alert('Achtung: Bestand niedrig!');
    const person = prompt('Wer nimmt es?');
    const reason = prompt('Grund/Kommentar:');
    history.push({product: products[index].name, amount, person, reason, time: new Date().toLocaleString()});
    localStorage.setItem('products', JSON.stringify(products));
    localStorage.setItem('history', JSON.stringify(history));
    renderProducts();
}
function renderHistory() {
    const list = document.getElementById('historyList');
    if (!list) return;
    list.innerHTML = '';
    history.forEach(h => {
        list.innerHTML += `<div class='product'>${h.time}: ${h.person} nahm ${h.amount}x ${h.product} (${h.reason})</div>`;
    });
}
renderProducts();
renderHistory();
